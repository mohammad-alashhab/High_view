<?php require 'partials/header.php'?>

      <h5>profile Information</h5>
      <hr>

      <div class="row">
        <div class="col-lg-8">
        <div class="card mb-4">
          <div class="card-body">
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Full Name</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo $userP['first_name']." " . $userP['last_name'];?></p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Email</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo $userP['email'];?></p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Phone</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo $userP['phone'];?></p>
              </div>
            </div>
        
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Address</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0"><?php echo $userP['city']." , ".$userP['district'] ." , ". $userP['street']." , ". $userP['building_num']?></p>
              </div>
            </div>
          </div>
        </div>
        <button type="button" class="btn btn-warning btn-custom mb-3"  onclick="appear()">Edit your profile </button>
          
      </div>

      <div style="display:none;" id="edit" class="custom-card">
    <div class="col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12">
        <form method="post" action="/user/edit">
            <div class="card">
                <div class="card-body">
                    <div class="row gutters">
                        <div class="col-xl-12">
                            <h6 class="mb-2 text-warning" >Personal Details</h6>
                        </div>
                        <div class="col-xl-12">
                            <div class="form-group">
                                <label for="firstName">First Name</label>
                                <input type="text" class="form-control" name="firstName" placeholder="Enter first name" value="<?php echo htmlspecialchars($userP['first_name']); ?>">
                            </div>
                        </div>
                        <div class="col-xl-12">
                            <div class="form-group">
                                <label for="lastName">Last Name</label>
                                <input type="text" class="form-control" name="lastName" placeholder="Enter last name" value="<?php echo htmlspecialchars($userP['last_name']); ?>">
                            </div>
                        </div>
                        <div class="col-xl-12">
                          <div class="form-group">
                             <label for="email" >Email</label>

                              <input type="email" class="form-control " name="email" placeholder="Enter email ID" value="<?php echo htmlspecialchars($userP['email']); ?>"  >
                        </div>



                        </div>


                        <div class="col-xl-12">
                            <div class="form-group">
                                <label for="phone">Phone</label>
                                <input type="tel" class="form-control" name="phone" placeholder="Enter phone number" value="<?php echo htmlspecialchars($userP['phone']); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row gutters">
                        <div class="col-xl-12">
                            <h6 class="mt-3 mb-2 text-warning">Address</h6>
                        </div>
                        <div class="col-xl-12">
                            <div class="form-group">
                                <label for="city">City</label>
                                <input type="text" class="form-control" name="city" placeholder="Enter City" value="<?php echo htmlspecialchars($userP['city']); ?>">
                            </div>
                        </div>
                        <div class="col-xl-12">
                            <div class="form-group">
                                <label for="district">District</label>
                                <input type="text" class="form-control" name="district" placeholder="Enter district" value="<?php echo htmlspecialchars($userP['district']); ?>">
                            </div>
                        </div>
                        <div class="col-xl-12">
                            <div class="form-group">
                                <label for="street">Street</label>
                                <input type="text" class="form-control" name="street" placeholder="Enter Street" value="<?php echo htmlspecialchars($userP['street']); ?>">
                            </div>
                        </div>
                        <div class="col-xl-12">
                            <div class="form-group">
                                <label for="buildingNumber">Building Number</label>
                                <input type="text" class="form-control" name="b_number" placeholder="Building number" value="<?php echo htmlspecialchars($userP['building_num']); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row gutters">
                        <div class="col-xl-12">
                            <div class="text-right">
                                <button type="button" class="btn btn-secondary" onclick="hide()">Cancel</button>
                                <button type="submit" class="btn btn-warning">Update</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>


  </main>
  <!-- page-content" -->
</div>
<!-- page-wrapper -->
<?php require('partials/footer.php'); ?>


<?php 
 if (isset($_SESSION['status']) && isset($_SESSION['message'])): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: '<?php echo $_SESSION['status']; ?>',
                title: '<?php echo $_SESSION['message']; ?>'
            });
        });
    </script>
    <?php
        // Clear the message after displaying it
        unset($_SESSION['status']);
        unset($_SESSION['message']);
    ?>
<?php endif; ?>


